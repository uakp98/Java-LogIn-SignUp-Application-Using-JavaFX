package application;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

public class SignUpController implements Initializable {
	@FXML
	private TextField name;
	@FXML
	private TextField email;
	@FXML
	private TextField username;
	@FXML
	private PasswordField password;
	@FXML
	private Button signup;
	@FXML
	private Hyperlink login_link;
	
	
	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		signup.setOnAction(new EventHandler<ActionEvent>() {
			
			@Override
			public void handle(ActionEvent arg0) {
				// TODO Auto-generated method stub
				if(!name.getText().trim().isEmpty() && !email.getText().trim().isEmpty() && !username.getText().trim().isEmpty() && !password.getText().trim().isEmpty()) {
					DBUtils.signUpUser(arg0, username.getText(), password.getText(), name.getText(), email.getText());
				}else {
					System.out.println("Please fill all information");
					Alert alert=new Alert(Alert.AlertType.ERROR);
					alert.setContentText("please fill in all information to Sign up!");
					alert.show();
				}
			}
		});
		
		login_link.setOnAction(new EventHandler<ActionEvent>() {
			
			@Override
			public void handle(ActionEvent arg0) {
				// TODO Auto-generated method stub
				DBUtils.changeScene(arg0, "SampleLogIn.fxml", "Log in!", null, null);
			}
		});
		
		
	}

}
