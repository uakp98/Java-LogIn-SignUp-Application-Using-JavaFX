package application;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

public class LoggedInController implements Initializable {
	@FXML
	private Button logout;
	@FXML
	private Label welcome;
	@FXML
	private Label welcome_application;
	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		logout.setOnAction(new EventHandler<ActionEvent>() {
					
			@Override
			public void handle(ActionEvent arg0) {
				// TODO Auto-generated method stub
				DBUtils.changeScene(arg0, "SampleLogIn.fxml", "Log in!", null,null);
			}
		});
	}
	public void setUserInformation(String name) {
		welcome.setText("Hi "+name+ " !");
		
	}

}
