package application;


import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.stage.Stage;

public class DBUtils {
	public static void changeScene(ActionEvent event, String fxmlFile, String title, String username, String name) {
		
		Parent root=null;
		if (username != null && name != null) {
			try {
				FXMLLoader loader= new FXMLLoader(DBUtils.class.getResource(fxmlFile));
				root=loader.load();
				
				LoggedInController loggedInController = loader.getController();
				loggedInController.setUserInformation(name);
				
				
			} catch(Exception e) {
				e.printStackTrace();
			}
		}
		else {
			try {
				root=FXMLLoader.load(DBUtils.class.getResource(fxmlFile));
				
			}catch(IOException e) {
				e.printStackTrace();
			}
		}
		
		Stage stage=(Stage)((Node)event.getSource()).getScene().getWindow();
		stage.setTitle(title);
		stage.setScene(new Scene(root, 600,400));
		stage.show();
	}
	
	public static void logInUser(ActionEvent event, String username, String password) {
		Connection con=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		
		try {
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Demologinsignup_Oct23_Java","root","");
			ps = con.prepareStatement("select * from user_details where username= ?");
			ps.setString(1, username);
			rs=ps.executeQuery();
			
			if(!rs.isBeforeFirst()) {
				System.out.println("User is not found in Database");
				Alert alert=new Alert(Alert.AlertType.ERROR);
				alert.setContentText("Username is not exist!");
				alert.show();
			}else {
				while(rs.next()) {
					String pass=rs.getString("password");
					String name=rs.getString("name");
					
					if(pass.equals(password)) {
						changeScene(event, "LoggedIn.fxml", "Welcome!", username, name);
					}else {
						System.out.println("Password is not correct");
						Alert alert=new Alert(Alert.AlertType.ERROR);
						alert.setContentText("Password is not correct!");
						alert.show();
					}
					
				}
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}finally{
			if(rs != null) {
				try {
					rs.close();
				}catch(SQLException e) {
					e.printStackTrace();
				}
			}
			if(ps != null) {
				try {
					ps.close();
				}catch(SQLException e) {
					e.printStackTrace();
				}
			}
			if(con != null) {
				try {
					con.close();
				}catch(SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}
	
	public static void signUpUser(ActionEvent event, String username, String password, String name, String email) {
		Connection con=null;
		PreparedStatement psInsert=null;
		PreparedStatement psUserExist = null;
		ResultSet rs=null;
		
		
		try {
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Demologinsignup_Oct23_Java","root","");
			psUserExist = con.prepareStatement("select * from user_details where username= ?");
			psUserExist.setString(1, username);
			rs=psUserExist.executeQuery();
			
			if(rs.isBeforeFirst()) { //if user already exists
				System.out.println("User already exists!");
				Alert alert=new Alert(Alert.AlertType.ERROR);
				alert.setContentText("You can't use this username as it's already registered.");
				alert.show();
			}else {		//if user not exists
				psInsert = con.prepareStatement("Insert into user_details (name, email, username, password) values (?,?,?,?)");
				psInsert.setString(1, name);
				psInsert.setString(2, email);
				psInsert.setString(3, username);
				psInsert.setString(4, password);
				
				psInsert.executeUpdate();
				
				System.out.println("Registered successful");
				Alert alert=new Alert(Alert.AlertType.INFORMATION);
				alert.setContentText("You have successfully registered!");
				alert.show();
				
				changeScene(event, "SampleLogIn.fxml", "Log in!", null, null);
			}
			
		}catch(SQLException e) {
			e.printStackTrace();
		}finally{
			if(rs != null) {
				try {
					rs.close();
				}catch(SQLException e) {
					e.printStackTrace();
				}
			}
			if(psUserExist != null) {
				try {
					psUserExist.close();
				}catch(SQLException e) {
					e.printStackTrace();
				}
			}
			if(psInsert != null) {
				try {
					psInsert.close();
				}catch(SQLException e) {
					e.printStackTrace();
				}
			}
			if(con != null) {
				try {
					con.close();
				}catch(SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}
}
